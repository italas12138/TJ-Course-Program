《Qt_BitTree》: 
第一部分 算法实现 工程文件，
题目为：第8题.二叉排序树的建立和删除
内含测试文件test_one.txt和test_two.txt和test_three.txt

《Qt_Texteditor》: 
第二部分 综合应用 工程文件，
题目为：第8题.文本编辑器
内含测试文件test_one.txt和test_two.txt和test_three.txt

环境配置见报告。