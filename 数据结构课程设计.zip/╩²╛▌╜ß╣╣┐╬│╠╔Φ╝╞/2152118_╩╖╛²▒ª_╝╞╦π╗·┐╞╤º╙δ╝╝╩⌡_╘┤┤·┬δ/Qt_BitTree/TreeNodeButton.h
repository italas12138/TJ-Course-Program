#ifndef TREENODEBUTTON_H
#define TREENODEBUTTON_H

#include <QPushButton>

class TreeNodeButton : public QPushButton
{
    Q_OBJECT
public:

    TreeNodeButton(double size, QString imgPath=":/new/img/pink.jpg");


signals:

};

#endif // TREENODEBUTTON_H
