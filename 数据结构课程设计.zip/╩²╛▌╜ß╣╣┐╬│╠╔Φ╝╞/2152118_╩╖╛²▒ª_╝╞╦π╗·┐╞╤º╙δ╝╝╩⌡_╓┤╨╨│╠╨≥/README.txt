《Qt_BitTree》: 
第一部分 算法实现 工程文件，
题目为：第8题.二叉排序树的建立和删除
内含测试文件test_one.txt和test_two.txt和test_three.txt

《Qt_Texteditor》: 
第二部分 综合应用 工程文件，
题目为：第8题.文本编辑器
内含测试文件test_one.txt和test_two.txt和test_three.txt

环境配置见报告。

双击exe文件后，如果弹出“缺少Qt5Widgetsd.dll”，
请按照该链接的教程设置环境变量：
https://blog.csdn.net/weixin_33994444/article/details/92712158