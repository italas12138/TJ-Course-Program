《course_design_2》: 
第一部分 算法实现工程文件，
题目为：第10题.哈希表的建立、查找、插入与删除
内含测试文件test_link.txt和test_open_addr.txt。

《course_design_data_struct》: 
第二部分 综合应用 工程文件，
题目为：第0题.通过线性表模拟树结构
内含测试文件test_correct.txt和test_err.txt。

环境配置见报告。